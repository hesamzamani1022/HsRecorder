# HsRecorder — ضبط‌کننده آشکار میکروفون (Android)

## وضعیت ساخت در این محیط
در این محیط (Code Interpreter sandbox) **Java JDK، Android SDK و Gradle نصب نیستند** و
دسترسی به اینترنت برای دانلود خودکار آن‌ها وجود ندارد. بنابراین تولید APK در همین محیط
انجام نمی‌شود. پروژه کامل و قابل‌کامپایل در `HsRecorder/` قرار داده شده است.

### نحوه ساخت APK روی سیستم خودتان
پیش‌نیازها: JDK 17، Android Studio (یا Android SDK با Build-Tools 34 و Platform android-34)

    cd HsRecorder
    gradle wrapper        # اگر wrapper script ندارید
    ./gradlew assembleDebug

خروجی: `HsRecorder/app/build/outputs/apk/debug/app-debug.apk`
روی Samsung S24 Ultra (Android 14) نصب می‌شود؛ کافی است Install unknown apps را برای مرورگر/فایل‌منیجر فعال کنید.

## رفتار برنامه
- فقط **میکروفون** را ضبط می‌کند و کاملاً آشکار است؛ هیچ تلاشی برای ضبط صدای تماس تلفنی
  یا صدای داخلی دو طرف تماس (که در Android 10+ مسدود شده) انجام نمی‌دهد.
- دکمه شروع/توقف + نمایش وضعیت + فهرست فایل‌ها.
- ذخیره در پوشه **hesamrecorder**:
  - Android 10+: `Downloads/hesamrecorder`
  - Android 9 و قدیمی‌تر: `/sdcard/hesamrecorder`
- فرمت: ابتدا تلاش برای **MP3**؛ اگر encoder MP3 در دستگاه موجود نباشد، به‌صورت خودکار
  به **AAC/M4A** (کدک استاندارد اندروید، بدون کتابخانه جانبی) برمی‌گردد.

## نکته درباره MP3
`MediaRecorder` اندروید به‌صورت رسمی خروجی MP3 نمی‌دهد. برای MP3 تضمینی باید کتابخانه‌ای
مثل `lame-android`/`Lame4Android` به پروژه اضافه شود (در این محیط بدون اینترنت ممکن نیست).
پس در عمل این اپ معمولاً خروجی **M4A/AAC** می‌دهد که روی همه پخش‌کننده‌ها پخش می‌شود.
