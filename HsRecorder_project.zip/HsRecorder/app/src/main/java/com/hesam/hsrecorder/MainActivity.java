package com.hesam.hsrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.MediaCodecList;
import android.media.MediaCodecInfo;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

/**
 * HsRecorder — ضبط‌کننده ساده و آشکارِ میکروفون.
 * فقط صدای میکروفون ضبط می‌شود؛ هیچ تلاشی برای دور زدن محدودیت‌های
 * ضبط صدای تماس تلفنی یا صدای داخلی (Android 10+) انجام نمی‌شود
 * و این کار مطابق سیاست‌های اندروید مجاز نیست.
 *
 * فرمت خروجی: AAC/M4A (کدک استاندارد اندروید).
 * MediaRecorder اندروید خروجی MP3 نمی‌دهد؛ اگر دستگاه MP3 encoder داشته باشد
 * (توسط hasMp3Encoder بررسی می‌شود) در وضعیت نمایش اعلام می‌شود، ولی در عمل
 * برای MP3 تضمینی باید کتابخانه LAME به پروژه اضافه شود.
 */
public class MainActivity extends Activity {

    private static final int REQ_MIC = 11;
    private MediaRecorder recorder;
    private boolean recording = false;
    private File outFile;

    private Button btnToggle;
    private TextView statusText, filesText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnToggle  = findViewById(R.id.btnToggle);
        statusText = findViewById(R.id.statusText);
        filesText  = findViewById(R.id.filesText);
        btnToggle.setOnClickListener(v -> { if (!recording) startRecording(); else stopRecording(); });
        refreshFileList();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
    }

    private void startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_SHORT).show();
            return;
        }
        File dir = getOutputDir();
        if (!dir.exists()) dir.mkdirs();
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        outFile = new File(dir, "HSREC_" + ts + ".m4a");
        try {
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setAudioSamplingRate(44100);
            recorder.setAudioChannels(1);
            recorder.setOutputFile(outFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            recording = true;
            btnToggle.setText(R.string.stop);
            statusText.setText(hasMp3Encoder()
                ? getString(R.string.status_recording) + " (M4A — MP3 نیاز به LAME)"
                : getString(R.string.status_recording));
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "خطا در شروع ضبط: " + e.getMessage(), Toast.LENGTH_LONG).show();
            if (recorder != null) { try { recorder.release(); } catch (Exception ignored) {} }
            recorder = null;
            recording = false;
        }
    }

    private void stopRecording() {
        try {
            if (recorder != null) { recorder.stop(); recorder.release(); }
        } catch (Exception e) { e.printStackTrace(); }
        finally {
            recorder = null;
            recording = false;
            btnToggle.setText(R.string.start);
            statusText.setText(R.string.status_idle);
            refreshFileList();
        }
    }

    /** بررسی وجود encoder نرم‌افزاری/سخت‌افزاری MP3 در دستگاه */
    private boolean hasMp3Encoder() {
        try {
            MediaCodecList list = new MediaCodecList(MediaCodecList.REGULAR_CODECS);
            for (MediaCodecInfo info : list.getCodecInfos()) {
                if (!info.isEncoder()) continue;
                for (String t : info.getSupportedTypes())
                    if (t.equalsIgnoreCase("audio/mpeg")) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** پوشه ذخیره: Android 10+ → Downloads/hesamrecorder (scoped storage)؛ قدیمی‌تر → /sdcard/hesamrecorder */
    private File getOutputDir() {
        if (Build.VERSION.SDK_INT >= 29) {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "hesamrecorder");
            if (!dir.exists()) dir.mkdirs();
            return dir;
        }
        File dir = new File(Environment.getExternalStorageDirectory(), "hesamrecorder");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private void refreshFileList() {
        try {
            File[] files = getOutputDir().listFiles();
            ArrayList<String> names = new ArrayList<>();
            if (files != null) for (File f : files) names.add(f.getName());
            Collections.sort(names, Collections.reverseOrder());
            StringBuilder sb = new StringBuilder();
            for (String n : names) sb.append(n).append("\n");
            filesText.setText(sb.length() > 0 ? sb.toString() : "—");
        } catch (Exception e) { filesText.setText("—"); }
    }

    @Override
    protected void onDestroy() { super.onDestroy(); if (recording) stopRecording(); }
}
